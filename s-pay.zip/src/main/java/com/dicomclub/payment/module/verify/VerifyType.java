package com.dicomclub.payment.module.verify;

/**
 * @author ftm
 * @date 2023/2/1 0001 10:23
 */
public class VerifyType {
    /**
     * MD5
     */
    public  final  static  String MD5="MD5";
    /**
     * MD5withRSA
     */
    public  final  static String MD5withRSA = "MD5withRSA";

    /**
     * MD5withAES
     */
    public  final  static String MD5withAES = "MD5withAES";
}
