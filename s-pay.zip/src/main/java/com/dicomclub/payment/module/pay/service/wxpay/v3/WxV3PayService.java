package com.dicomclub.payment.module.pay.service.wxpay.v3;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dicomclub.payment.exception.PayException;
import com.dicomclub.payment.module.pay.common.TransactionType;
import com.dicomclub.payment.module.pay.config.PayConfig;
import com.dicomclub.payment.module.pay.config.WxPayConfig;
import com.dicomclub.payment.module.pay.enums.PayChannel;
import com.dicomclub.payment.module.pay.model.PayRequest;
import com.dicomclub.payment.module.pay.model.PayResponse;
import com.dicomclub.payment.module.pay.model.wxpay.WxPayRequest;
import com.dicomclub.payment.module.pay.model.wxpay.WxPayResponse;
import com.dicomclub.payment.module.pay.service.union.common.OrderParaStructure;
import com.dicomclub.payment.module.pay.service.union.common.sign.SignTextUtils;
import com.dicomclub.payment.module.pay.service.union.common.sign.SignUtils;
import com.dicomclub.payment.module.pay.service.union.common.sign.encrypt.RSA2;
import com.dicomclub.payment.module.pay.service.wxpay.WxPayStrategy;
import com.dicomclub.payment.module.pay.service.wxpay.v3.common.*;
import com.dicomclub.payment.util.DateUtils;
import com.dicomclub.payment.util.httpRequest.*;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.message.BasicHeader;
import org.springframework.stereotype.Component;

import java.security.PrivateKey;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.dicomclub.payment.module.pay.service.wxpay.v3.common.WxConst.SANDBOXNEW;
import static org.apache.http.entity.ContentType.APPLICATION_JSON;

/**
 * @author ftm
 * @date 2023/3/3 0003 10:49
 */
@Component
public class WxV3PayService extends WxPayStrategy{
    /**
     * api服务地址，默认为国内
     */
    private String apiServerUrl = WxConst.URI;


    private HttpRequestTemplate requestTemplate = null;



    public WxV3PayService(){
        //请求连接池配置
        HttpConfigStorage httpConfigStorage = new HttpConfigStorage();
        //最大连接数
        httpConfigStorage.setMaxTotal(20);
        //默认的每个路由的最大连接数
        httpConfigStorage.setDefaultMaxPerRoute(10);
        requestTemplate = new HttpRequestTemplate(httpConfigStorage);
    }

    @Override
    public PayResponse pay(PayRequest payRequest, PayConfig payConfig) {
        WxPayRequest request = (WxPayRequest) payRequest;
        WxPayConfig payConfigStorage =(WxPayConfig) payConfig;
        ////统一下单
        JSONObject result = unifiedOrder(request,payConfigStorage);
//       交易类型判断
        WxTransactionType wxTransactionType = null;
        PayChannel payChannel = request.getPayChannel();
        if(PayChannel.WXPAY_MINI == payChannel ||PayChannel.WXPAY_MP == payChannel){
            wxTransactionType = WxTransactionType.JSAPI;
        }else if(PayChannel.WXPAY_APP == payChannel){
            wxTransactionType = WxTransactionType.APP;
        }else if(PayChannel.WXPAY_MICRO == payChannel  ){
            wxTransactionType = WxTransactionType.NATIVE;
        }else if(PayChannel.WXPAY_NATIVE == payChannel){
            wxTransactionType = WxTransactionType.NATIVE;
        }else if(PayChannel.WXPAY_MWEB == payChannel){
            wxTransactionType = WxTransactionType.H5;
        }
        WxPayResponse wxPayResponse = new WxPayResponse();

        //如果是扫码支付或者刷卡付无需处理，直接返回
        if (wxTransactionType.isReturn()) {
            wxPayResponse.setDataMap(result);
            return wxPayResponse;
        }


        Map<String, Object> params = new LinkedHashMap<>();
        String appId = payConfigStorage.getAppId();
        if (payConfigStorage.isPartner() && StringUtils.isNotEmpty(payConfigStorage.getSubAppId())) {
            appId = payConfigStorage.getSubAppId();
        }
        String timeStamp = String.valueOf(DateUtils.toEpochSecond());
        String randomStr = SignTextUtils.randomStr();
        String prepayId = result.getString("prepay_id");
        if (WxTransactionType.JSAPI == wxTransactionType) {
            params.put("appId", appId);
            params.put("timeStamp", timeStamp);
            params.put("nonceStr", randomStr);
            prepayId = "prepay_id=" + prepayId;
            params.put("package", prepayId);
            params.put("signType", SignUtils.RSA.getName());
        }
        else if (WxTransactionType.APP ==wxTransactionType) {
            params.put(WxConst.APPID, appId);
            params.put("partnerid", payConfigStorage.getMchId());
            params.put("timestamp", timeStamp);
            params.put("noncestr", randomStr);
            params.put("prepayid", prepayId);
            params.put("package", "Sign=WXPay");
        }
        String signText = StringUtils.joining("\n", appId, timeStamp, randomStr, prepayId);
        String paySign = createSign(signText, payConfigStorage.getInputCharset(),payConfigStorage);
        params.put(WxTransactionType.JSAPI.equals(wxTransactionType) ? "paySign" : "sign", paySign);
        wxPayResponse.setDataMap(params);
        return wxPayResponse;
    }





    /**
     * 微信统一下单接口
     *
     * @param order 支付订单集
     * @return 下单结果
     */
    public JSONObject unifiedOrder(WxPayRequest order ,WxPayConfig payConfig) {

        //统一下单
        Map<String, Object> parameters =  initPartner(null,payConfig);
//        wxParameterStructure.getPublicParameters(parameters);
        // 商品描述
        OrderParaStructure.loadParameters(parameters, WxConst.DESCRIPTION, order.getOrderName());
        OrderParaStructure.loadParameters(parameters, WxConst.DESCRIPTION, order.getOrderDesc());
        // 订单号
        parameters.put(WxConst.OUT_TRADE_NO, order.getOrderNo());
        //交易结束时间
        if (null != order.getExpirationTime()) {
            parameters.put("time_expire", DateUtils.formatDate(order.getExpirationTime(), DateUtils.YYYY_MM_DD_T_HH_MM_SS_XX));
        }
        OrderParaStructure.loadParameters(parameters, "attach", order.getAttach());
        initNotifyUrl(parameters, order,payConfig);
        //订单优惠标记
        OrderParaStructure.loadParameters(parameters, "goods_tag", order);
        parameters.put("amount", Amount.getAmount(order.getOrderAmount(), order.getCurType()));

        //优惠功能
        OrderParaStructure.loadParameters(parameters, "detail", order);
        //支付场景描述
        OrderParaStructure.loadParameters(parameters, WxConst.SCENE_INFO, order);
        loadSettleInfo(parameters, order);
        WxTransactionType transactionType = null;
        switch (order.getPayChannel()){
            case WXPAY_MP:
                transactionType = WxTransactionType.JSAPI;
                break;
            case WXPAY_MINI:
                transactionType = WxTransactionType.JSAPI;
                break;
            case WXPAY_APP:
                transactionType = WxTransactionType.APP;
                break;
            case WXPAY_MWEB:
                transactionType = WxTransactionType.H5;
                break;
            case WXPAY_NATIVE:
                transactionType = WxTransactionType.NATIVE;
                break;
            case WXPAY_MICRO:
                transactionType = WxTransactionType.NATIVE;
                break;
            default:
                throw new PayException("错误的渠道");
        }
        transactionType.setAttribute(parameters, order);
        // 订单附加信息，可用于预设未提供的参数，这里会覆盖以上所有的订单信息，
        parameters.putAll(order.getAttrs());
        String requestBody = JSON.toJSONString(parameters);

        return  doExecute(requestBody,transactionType, payConfig);
    }

    public JSONObject doExecute(String body, TransactionType transactionType,WxPayConfig payConfig, Object... uriVariables ) {
        String reqUrl = UriVariables.getUri(getReqUrl(transactionType,payConfig), uriVariables);
        MethodType method = MethodType.valueOf(transactionType.getMethod());
        if (MethodType.GET == method && StringUtils.isNotEmpty(body)) {
            reqUrl += UriVariables.QUESTION.concat(body);
            body = "";
        }
        HttpEntity entity = buildHttpEntity(reqUrl, body, transactionType.getMethod(),payConfig);
        ResponseEntity<JSONObject> responseEntity = requestTemplate.doExecuteEntity(reqUrl, entity, JSONObject.class, method);

        int statusCode = responseEntity.getStatusCode();
        JSONObject responseBody = responseEntity.getBody();
        if (statusCode >= 400) {
            throw new PayException(responseBody.getString(WxConst.CODE)+ responseBody.getString(WxConst.MESSAGE));
        }
        return responseBody;
    }

    /**
     * 构建请求实体
     * 这里也做签名处理
     *
     * @param url   url
     * @param body   请求内容体
     * @param method 请求方法
     * @return 请求实体
     */
    public HttpEntity buildHttpEntity(String url, String body, String method ,WxPayConfig payConfigStorage) {
        String nonceStr = SignTextUtils.randomStr();
        long timestamp = DateUtils.toEpochSecond();
        String canonicalUrl = UriVariables.getCanonicalUrl(url);
        //签名信息
        String signText = com.dicomclub.payment.module.pay.service.wxpay.v3.common.StringUtils.joining("\n", method, canonicalUrl, String.valueOf(timestamp), nonceStr, body);
        String sign = createSign(signText, payConfigStorage.getInputCharset(),payConfigStorage);
        String serialNumber = payConfigStorage.getCertEnvironment().getSerialNumber();
        // 生成token
        String token = String.format(WxConst.TOKEN_PATTERN, payConfigStorage.getMchId(), nonceStr, timestamp, serialNumber, sign);
        HttpStringEntity entity = new HttpStringEntity(body, ContentType.APPLICATION_JSON);
        entity.addHeader(new BasicHeader("Authorization", WxConst.SCHEMA.concat(token)));
        entity.addHeader(new BasicHeader("User-Agent", "Pay-Java-Parent"));
        entity.addHeader(new BasicHeader("Accept", APPLICATION_JSON.getMimeType()));
        return entity;
    }


    public String createSign(String content, String characterEncoding ,WxPayConfig payConfigStorage) {
        PrivateKey privateKey = payConfigStorage.getCertEnvironment().getPrivateKey();
        return RSA2.sign(content, privateKey, characterEncoding);
    }

    /**
     * 根据交易类型获取url
     *
     * @param transactionType 交易类型
     * @return 请求url
     */
    public String getReqUrl(TransactionType transactionType,WxPayConfig payConfigStorage) {
        String type = transactionType.getType();
        String partnerStr = "";
        if (payConfigStorage.isPartner()) {
            partnerStr = "/partner";
        }
        type = type.replace("{partner}", partnerStr);
        return apiServerUrl + (payConfigStorage.isSandbox() ? SANDBOXNEW : "") + type;
    }


    /**
     * 初始化商户相关信息
     *
     * @param parameters 参数信息
     * @return 参数信息
     */
    public Map<String, Object> initPartner(Map<String, Object> parameters, WxPayConfig payConfigStorage) {
        if (null == parameters) {
            parameters = new LinkedHashMap<>();
        }
        if (payConfigStorage.isPartner()) {
            parameters.put("sp_appid", payConfigStorage.getAppId());
            parameters.put(WxConst.SP_MCH_ID, payConfigStorage.getMchId());
            OrderParaStructure.loadParameters(parameters, "sub_appid", payConfigStorage.getSubAppId());
            OrderParaStructure.loadParameters(parameters, WxConst.SUB_MCH_ID, payConfigStorage.getSubMchId());
            return parameters;
        }

        parameters.put(WxConst.APPID, payConfigStorage.getAppId());
        parameters.put(WxConst.MCH_ID, payConfigStorage.getMchId());
        return parameters;
    }



    /**
     * 初始化通知URL必须为直接可访问的URL，不允许携带查询串，要求必须为https地址。
     *
     * @param parameters 订单参数
     * @param order      订单信息
     */
    public void initNotifyUrl(Map<String, Object> parameters,PayRequest order,WxPayConfig wxPayConfig) {
        OrderParaStructure.loadParameters(parameters, WxConst.NOTIFY_URL, wxPayConfig.getNotifyUrl());
        OrderParaStructure.loadParameters(parameters, WxConst.NOTIFY_URL, order.getNotifyUrl());
        OrderParaStructure.loadParameters(parameters, WxConst.NOTIFY_URL, order);
    }


    /**
     * 加载结算信息
     *
     * @param parameters 订单参数
     * @param order      支付订单
     */
    public void loadSettleInfo(Map<String, Object> parameters, PayRequest order) {
        Object profitSharing = order.getAttr("profit_sharing");
        if (null != profitSharing) {
            Map<String, Object> settleInfo = new MapGen<>("profit_sharing", profitSharing).getAttr();
            parameters.put("settle_info", settleInfo);
            return;
        }
        //结算信息
        OrderParaStructure.loadParameters(parameters, "settle_info", order);


    }
}
