package com.dicomclub.payment.module.pay.model.wxpay.response;

/**
 * 微信退款结果异步通知
 * copy by ftm
 * 2018-05-30 16:29
 */
public class WxRefundNotifyResponse {
}
