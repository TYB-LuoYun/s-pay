package com.dicomclub.payment.common.constants;

public class RedisConstant {
    public static final String RESOURCE_ROLES_MAP = "RESOURCE_ROLES_MAP";
}
