package com.dicomclub.payment.util.httpRequest;

/**
 * @author ftm
 * @date 2023/2/21 0021 13:56
 */
public enum MethodType {
    GET, POST
}
